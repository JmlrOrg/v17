run('../cep/startup.m')
